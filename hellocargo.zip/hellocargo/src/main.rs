fn main() {
    println!("Hello, Welcome from Cargo!");
}
